<?php
include_once('../../../common.php');
$num = 1;
$title = '회사소개';
include_once(G5_THEME_PATH.'/head.php');
?>

<div class="sub">
    여기 회사소개 넣을거임... <?= $num ?>
</div>


<?php
include_once(G5_THEME_PATH.'/tail.php');