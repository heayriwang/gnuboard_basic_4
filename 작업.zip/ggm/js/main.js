$(function () {
    $('.main_slide').slick({
        arrows: false,
        dots: true,
        vertical: true,
    })
})